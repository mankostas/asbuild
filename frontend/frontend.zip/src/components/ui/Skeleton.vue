<template>
  <div :class="['animate-pulse rounded-2xl bg-foreground/10', $attrs.class]" />
</template>
<script setup lang="ts"></script>
