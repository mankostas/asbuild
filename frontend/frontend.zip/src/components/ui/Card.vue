<template>
  <div
    class="rounded-2xl border border-foreground/10 bg-background/80 p-4 text-foreground shadow-lg backdrop-blur-sm"
  >
    <slot />
  </div>
</template>
