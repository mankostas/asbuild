<template>
  <div class="p-8 text-center">
    <h1 class="text-2xl mb-4">Page Not Found</h1>
    <p>The page you are looking for doesn't exist.</p>
  </div>
</template>

<script setup>
// no logic needed
</script>
