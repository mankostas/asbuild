<?php

namespace App\Http\Middleware;

use Illuminate\Routing\Middleware\ValidateSignature;

class SignedUrl extends ValidateSignature
{
}
