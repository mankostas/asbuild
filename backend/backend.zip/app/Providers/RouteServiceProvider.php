<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * Define your route model bindings, pattern filters, etc.
     */
    public function boot(): void
    {
        RateLimiter::for('auth', function ($request) {
            return Limit::perMinute(5)->by($request->ip());
        });

        RateLimiter::for('uploads', function ($request) {
            return Limit::perMinute(30)->by(optional($request->user())->id ?: $request->ip());
        });

        Route::fallback(function () {
            $index = public_path('index.html');
            return file_exists($index) ? response()->file($index) : abort(404);
        });
    }
}
